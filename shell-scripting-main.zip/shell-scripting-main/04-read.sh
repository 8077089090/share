#!/usr/bin/bash

read -p 'Enter your Name: ' name

echo "Your Name = $name"
