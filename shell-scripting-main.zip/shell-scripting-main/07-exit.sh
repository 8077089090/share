#!/bin/bash

echo Hello
exit 100
echo Bye