#!/usr/bin/bash

ls
#head /etc/passwd

