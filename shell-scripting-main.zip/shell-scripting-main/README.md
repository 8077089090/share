# shell-scripting

Topics:

1. She-Bang & Comments
2. Print 
3. Variables 
4. Input 
5. Functions 
6. Redirectors & Quotes 
7. Conditions 
8. Loops